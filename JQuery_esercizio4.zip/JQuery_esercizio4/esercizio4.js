$(document).ready( function() {

   r=5;
   c=5;
   for(i=0;i<r;i++)
   {
      for(j=0;j<c;j++)
      {
         nuovo = document.createElement('div');
         nuovo.setAttribute('id', 'd'+i+j);
         nuovo.setAttribute('class', 'miediv');
         nuovo.setAttribute('i', i);
         nuovo.setAttribute('j', j);
         nuovo.setAttribute('valore', 0);
         $("body").append(nuovo);

         t=(i*55)+10;
         l=(j*55)+10;
         $("#d"+i+j).css({ 'top':t, 'left':l });
         h=$("#d"+i+j).attr('valore');
         $("#d"+i+j).html(h);

         $("#d"+i+j).click( function() {

            pi=$(this).attr('i');
            pj=$(this).attr('j');

            for(z=0;z<r;z++)
            {
               ph=$("#d"+z+pj).attr('valore');
               ph++;
               if(ph>9) ph=0;
               $("#d"+z+pj).attr('valore',ph);
               $("#d"+z+pj).html(ph);
               if(ph%2==0)
                  colo='rgb(0,0,150)';
               else
                  colo='rgb(150,0,0)';
               $("#d"+z+pj).css({ 'background-color':colo });
            }

            for(z=0;z<c;z++)
            {
               if(z!=pj)
               {
                  ph=$("#d"+pi+z).attr('valore');
                  ph++;
                  if(ph>9) ph=0;
                  $("#d"+pi+z).attr('valore',ph);
                  $("#d"+pi+z).html(ph);
                  if(ph%2==0)
                     colo='rgb(0,0,150)';
                  else
                     colo='rgb(150,0,0)';
                  $("#d"+pi+z).css({ 'background-color':colo });
               }
            }

         });
      }
   }

});

