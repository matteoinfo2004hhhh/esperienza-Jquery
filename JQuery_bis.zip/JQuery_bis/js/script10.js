$(document).ready( function() {
 
   width=0;
   height=0;
   x=4;
   y=3;

   var a = new Array();
   for(j=0;j<y;j++)
   {
      a[j] = new Array();
      for(i=0;i<x;i++)
      {
         a[j][i]=j+""+i;
      }
   } 

   nuovo = document.createElement('div');
   nuovo.setAttribute('id', 'finestra');
   nuovo.setAttribute('class', 'sagome');
   $("body").append(nuovo);

   nuovo = document.createElement('div');
   nuovo.setAttribute('id', 'messaggi');
   nuovo.setAttribute('class', 'sagome');
   $("body").append(nuovo);


   for(j=0;j<y;j++)
   {
      for(i=0;i<x;i++)
      {

         nuovo = document.createElement('div');
         nuovo.setAttribute('id', 'd'+j+i);
         nuovo.setAttribute('class', 'miediv');
         nuovo.setAttribute('testo',a[j][i]);
         $("#finestra").append(nuovo);
         
         width=parseInt($("#d00").css('width'));
         height=parseInt($("#d00").css('height'));
         t=10+(j*(width+10));
         l=10+(i*(height+10));
         $("#d"+j+i).css({ 'top':t, 'left':l });
 
         $("#d"+j+i).hover( 
         function() {
            t=$(this).attr('testo'); 
            $(this).css({ 'background-color':'rgb(255,0,0)' });
            $("#messaggi").html("<b>"+t+"</b>");
         },
         function() { 
            $(this).css({ 'background-color':'rgb(0,0,150)' });
            $("#messaggi").html("");
         }
         );
      }
   }

   $("#finestra").css({ 
      'background-color':'rgba(0,200,0,1.0)',
      'top':'20px',
      'height':(height+10)*y+12,
      'width':(width+10)*x+12,
      'margin':'0 0 0 '+((-0.5)*(width+10)*x+12)
   });

   $("#messaggi").css({ 
      'background-color':'rgba(0,200,200,1.0)',
      'top':(height+10)*y+(height*0.8),
      'font-size':height*0.25,
      'height':height*0.5,
      'width':(width+10)*x+12,
      'margin':'0 0 0 '+((-0.5)*(width+10)*x+12)
   });

});   

