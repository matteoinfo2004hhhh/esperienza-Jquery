$(document).ready( function() {
 
   var a = new Array();
   a[0]="primo";
   a[1]="secondo";
   a[2]="terzo";
   a[3]="quarto";

   var t = new Array();
   t[0]=10;
   t[1]=10;
   t[2]=80;
   t[3]=80;
   var l = new Array();
   l[0]=10;
   l[1]=130;
   l[2]=10;
   l[3]=130;

   var colo = new Array();
   colo[0]="rgb(0,0,0)";
   colo[1]="rgb(0,0,150)";
   colo[2]="rgb(0,150,0)";
   colo[3]="rgb(150,0,0)";

   z=4;
   for(i=0;i<z;i++)
   {

      nuovo = document.createElement('div');
      nuovo.setAttribute('id', 'd'+i);
      nuovo.setAttribute('class', 'miediv');
      $("body").append(nuovo);

      $("#d"+i).css({ 
          'background-color':colo[i], 
          'top':t[i], 
          'left':l[i],
          'position':'absolute', 
          'z-index':i 
      });
      $("#d"+i).html(a[i]+" ("+$("#d"+i).attr('id')+" - "+$("#d"+i).css('z-index')+")");

      $("#d"+i).click( function() {
          ii=$(this).index();
          $(this).css({ 'z-index':3 });
          ni=0; 
          for(k=0;k<z;k++)
          {
             if(k!=ii)
             {
                $("#d"+k).css({'z-index':ni });
                ni++;
             }
             $("#d"+k).html(a[k]+" ("+$("#d"+k).attr('id')+" - "+$("#d"+k).css('z-index')+")");
          }
      });

   }
});   

