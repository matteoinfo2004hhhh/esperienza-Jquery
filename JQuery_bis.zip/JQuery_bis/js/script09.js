$(document).ready( function() {
 
   x=4;
   y=3;

   var a = new Array();
   for(j=0;j<y;j++)
   {
      a[j] = new Array();
      for(i=0;i<x;i++)
      {
         a[j][i]=j+""+i;
      }
   } 

   nuovo = document.createElement('div');
   nuovo.setAttribute('id', 'finestra');
   nuovo.setAttribute('class', 'sagome');
   $("body").append(nuovo);

   nuovo = document.createElement('div');
   nuovo.setAttribute('id', 'messaggi');
   nuovo.setAttribute('class', 'sagome');
   $("body").append(nuovo);
   $("#messaggi").css({ 
      'background-color':'rgba(0,200,200,1.0)',
      'top':'380px',
      'height':'100px'
   });

   for(j=0;j<y;j++)
   {
      for(i=0;i<x;i++)
      {

         nuovo = document.createElement('div');
         nuovo.setAttribute('id', 'd'+j+i);
         nuovo.setAttribute('class', 'miediv');
         nuovo.setAttribute('i', i);
         nuovo.setAttribute('j', j);
         nuovo.setAttribute('testo',a[j][i]);
         $("#finestra").append(nuovo);

         t=10+(j*110);
         l=10+(i*110);

         $("#d"+j+i).css({ 'top':t, 'left':l });
 
         $("#d"+j+i).hover( function() {
            fi=$(this).attr('i'); 
            fj=$(this).attr('j'); 
            t=$(this).attr('testo'); 
            $("#messaggi").html(t);
         });
      }
   }

});   

